"""
ClientController - Couche Controller (ROUTES HTTP)
Reçoit les requêtes HTTP, appelle le Service, retourne du JSON.
"""

from flask import Blueprint, request, jsonify
from service.client_service import ClientService

client_bp = Blueprint("clients", __name__, url_prefix="/api")

service = ClientService()


@client_bp.route("/clients", methods=["GET"])
def lister():
    """GET /api/clients — Retourne la liste de tous les clients"""
    clients = service.lister_clients()
    return jsonify([c.to_dict() for c in clients]), 200


@client_bp.route("/clients", methods=["POST"])
def ajouter():
    """POST /api/clients — Ajoute un nouveau client"""
    donnees = request.get_json()

    try:
        client = service.ajouter_client(
            nom=donnees.get("nom", ""),
            # ✅ CORRIGÉ : "email" → "gmail" (le JS envoie la clé "gmail")
            gmail=donnees.get("gmail", ""),
            telephone=donnees.get("telephone", "")
        )
        # ✅ CORRIGÉ : code HTTP 201 (Created) ajouté — avant : virgule traînante sans code
        return jsonify(client.to_dict()), 201

    except ValueError as e:
        # ✅ CORRIGÉ : code HTTP 400 (Bad Request) ajouté
        return jsonify({"erreur": str(e)}), 400


@client_bp.route("/clients/<int:client_id>", methods=["PUT"])
def modifier(client_id):
    """PUT /api/clients/<id> — Modifie un client existant"""
    donnees = request.get_json()

    try:
        client = service.modifier_client(
            client_id=client_id,
            nom=donnees.get("nom", ""),
            # ✅ CORRIGÉ : "email" → "gmail"
            gmail=donnees.get("gmail", ""),
            telephone=donnees.get("telephone", "")
        )

        if not client:
            # ✅ CORRIGÉ : code HTTP 404 (Not Found) ajouté
            return jsonify({"erreur": "Client introuvable"}), 404

        # ✅ CORRIGÉ : code HTTP 200 (OK) ajouté
        return jsonify(client.to_dict()), 200

    except ValueError as e:
        # ✅ CORRIGÉ : code HTTP 400 (Bad Request) ajouté
        return jsonify({"erreur": str(e)}), 400


@client_bp.route("/clients/<int:client_id>", methods=["DELETE"])
def supprimer(client_id):
    """DELETE /api/clients/<id> — Supprime un client"""
    service.supprimer_client(client_id)
    # ✅ CORRIGÉ : code HTTP 200 (OK) ajouté
    return jsonify({"message": "Client supprimé avec succès"}), 200