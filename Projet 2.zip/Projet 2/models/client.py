"""
Modèle Client - Représente un client dans le système
Architecture en couche : MODÈLE (entité métier)
"""

class Client:
    """Classe représentant un client"""

    def __init__(self, id, nom, gmail, telephone="", numero=None):
        self.id        = id
        self.nom       = nom
        self.gmail     = gmail        # ✅ CORRIGÉ : "email" → "gmail" (cohérent avec DB et JS)
        self.telephone = telephone
        self.numero    = numero       # Numéro d'ordre dans la liste (1, 2, 3…)

    def to_dict(self):
        """Convertir l'objet en dictionnaire JSON"""
        return {
            "id":        self.id,
            "nom":       self.nom,
            "gmail":     self.gmail,   # ✅ CORRIGÉ : "email" → "gmail" (le JS attend "gmail")
            "telephone": self.telephone,
            "numero":    self.numero
        }

    def __repr__(self):
        return f"Client(id={self.id}, nom={self.nom})"