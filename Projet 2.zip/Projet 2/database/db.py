"""
Connexion et initialisation SQLite
"""

import sqlite3
import os


def get_connection():
    """Retourne une connexion à la base de données SQLite"""
    chemin = os.path.join(os.path.dirname(__file__), "clients.db")
    conn = sqlite3.connect(chemin)
    conn.row_factory = sqlite3.Row   # accès aux colonnes par leur nom
    return conn


def init_db():
    """Crée la table clients si elle n'existe pas"""
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS clients (
            id        INTEGER PRIMARY KEY AUTOINCREMENT,
            nom       TEXT NOT NULL,
            telephone TEXT DEFAULT '',
            gmail     TEXT NOT NULL
        )
    """)
    conn.commit()
    conn.close()
    print("[DB] Base de données prête.")