Instruction pour lancer l'application web :
lancer app.py
ensuite copier le lien http affiché sur le terminal dans un navigateur pour ouvrir l'application  