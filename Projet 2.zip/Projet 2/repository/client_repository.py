"""
ClientRepository - Couche d'accès aux données (REPOSITORY)
Toutes les opérations SQL sur la table clients sont ici.
"""

from database.db import get_connection
from models.client import Client


class ClientRepository:
    """Gère les requêtes SQL pour les clients"""

    def ajouter(self, client):
        """INSERT : Ajoute un nouveau client en base"""
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute(
            "INSERT INTO clients (nom, gmail, telephone) VALUES (?, ?, ?)",
            (client.nom, client.gmail, client.telephone)
        )
        conn.commit()
        client.id = cursor.lastrowid
        conn.close()
        return client

    def obtenir_tous(self):
        """SELECT ALL : Retourne tous les clients triés par ID avec un numéro d'ordre"""
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT id, nom, gmail, telephone FROM clients ORDER BY id")
        lignes = cursor.fetchall()
        conn.close()

        clients = []
        for numero, ligne in enumerate(lignes, start=1):
            c = Client(
                id=ligne["id"],
                nom=ligne["nom"],
                gmail=ligne["gmail"],
                telephone=ligne["telephone"] or "",
                numero=numero
            )
            clients.append(c)
        return clients

    def obtenir_par_id(self, client_id):
        """SELECT ONE : Retourne un client par son ID"""
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM clients WHERE id = ?", (client_id,))
        ligne = cursor.fetchone()
        conn.close()

        if ligne:
            return Client(
                id=ligne["id"],
                nom=ligne["nom"],
                gmail=ligne["gmail"],
                telephone=ligne["telephone"] or "",
            )
        return None

    def modifier(self, client):
        """UPDATE : Met à jour les infos d'un client (l'ID ne change pas)"""
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute(
            "UPDATE clients SET nom=?, gmail=?, telephone=? WHERE id=?",
            (client.nom, client.gmail, client.telephone, client.id)
        )
        conn.commit()
        conn.close()

    def supprimer(self, client_id):
        """DELETE : Supprime un client par son ID"""
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("DELETE FROM clients WHERE id = ?", (client_id,))
        conn.commit()
        conn.close()

    # ─────────────────────────────────────────────
    # ✅ NOUVEAU : vérifications d'unicité
    # ─────────────────────────────────────────────

    def gmail_existe(self, gmail, exclude_id=None):
        """
        Vérifie si une adresse gmail est déjà utilisée par un autre client.
        exclude_id : exclure un client de la recherche (utile lors d'un UPDATE
                     pour ne pas bloquer le client qui garde son propre gmail).
        Retourne True si l'adresse est déjà prise, False sinon.
        """
        conn = get_connection()
        cursor = conn.cursor()

        if exclude_id is not None:
            cursor.execute(
                "SELECT 1 FROM clients WHERE gmail = ? AND id != ?",
                (gmail, exclude_id)
            )
        else:
            cursor.execute(
                "SELECT 1 FROM clients WHERE gmail = ?",
                (gmail,)
            )

        existe = cursor.fetchone() is not None
        conn.close()
        return existe

    def telephone_existe(self, telephone, exclude_id=None):
        """
        Vérifie si un numéro de téléphone est déjà utilisé par un autre client.
        exclude_id : même logique que gmail_existe.
        Retourne True si le numéro est déjà pris, False sinon.
        """
        conn = get_connection()
        cursor = conn.cursor()

        if exclude_id is not None:
            cursor.execute(
                "SELECT 1 FROM clients WHERE telephone = ? AND id != ?",
                (telephone, exclude_id)
            )
        else:
            cursor.execute(
                "SELECT 1 FROM clients WHERE telephone = ?",
                (telephone,)
            )

        existe = cursor.fetchone() is not None
        conn.close()
        return existe