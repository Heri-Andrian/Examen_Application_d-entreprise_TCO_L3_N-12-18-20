const sections =
document.querySelectorAll(".section");

function showSection(id){

    sections.forEach(section=>{
        section.classList.remove("active");
    });

    document
    .getElementById(id)
    .classList
    .add("active");

    loadClients();
}

function loadClients(){

    fetch("/api/clients")
    .then(response=>response.json())
    .then(clients=>{

        document.getElementById(
            "totalClients"
        ).textContent = clients.length;

        const listTable =
        document.getElementById(
            "listTable"
        );

        const manageTable =
        document.getElementById(
            "manageTable"
        );

        listTable.innerHTML="";
        manageTable.innerHTML="";

        clients.forEach(client=>{

            listTable.innerHTML += `
            <tr>
                <td>${client.numero}</td>
                <td>${client.nom}</td>
                <td>${client.telephone}</td>
                <td>${client.gmail}</td>
            </tr>
            `;

            manageTable.innerHTML += `
            <tr>
                <td>${client.numero}</td>
                <td>${client.nom}</td>
                <td>${client.telephone}</td>
                <td>${client.gmail}</td>

                <td>

                    <button
                    class="action-btn edit-btn"
                    onclick="openEdit(
                    ${client.id},
                    '${client.nom}',
                    '${client.telephone}',
                    '${client.gmail}'
                    )">
                    Modifier
                    </button>

                    <button
                    class="action-btn delete-btn"
                    onclick="deleteClient(
                    ${client.id}
                    )">
                    Supprimer
                    </button>

                </td>
            </tr>
            `;
        });

    });
}

document
.getElementById("addForm")
.addEventListener(
"submit",
function(e){

    e.preventDefault();

    fetch("/api/clients",{

        method:"POST",

        headers:{
            "Content-Type":
            "application/json"
        },

        body:JSON.stringify({

            nom:
            document.getElementById(
            "nom"
            ).value,

            telephone:
            document.getElementById(
            "telephone"
            ).value,

            gmail:
            document.getElementById(
            "gmail"
            ).value

        })

    })
    .then(()=>{

        this.reset();
        loadClients();

    });

});

function deleteClient(id){

    if(
        !confirm(
        "Supprimer ce client ?"
        )
    ){
        return;
    }

    fetch("/api/clients/"+id,{
        method:"DELETE"
    })
    .then(()=>{
        loadClients();
    });

}

function openEdit(
id,
nom,
telephone,
gmail
){

    document
    .getElementById(
    "editId"
    ).value=id;

    document
    .getElementById(
    "editNom"
    ).value=nom;

    document
    .getElementById(
    "editTelephone"
    ).value=telephone;

    document
    .getElementById(
    "editGmail"
    ).value=gmail;

    document
    .getElementById(
    "modal"
    ).style.display="flex";

}

function closeModal(){

    document
    .getElementById(
    "modal"
    ).style.display="none";

}

function saveEdit(){

    const id =
    document
    .getElementById(
    "editId"
    ).value;

    fetch("/api/clients/"+id,{

        method:"PUT",

        headers:{
            "Content-Type":
            "application/json"
        },

        body:JSON.stringify({

            nom:
            document
            .getElementById(
            "editNom"
            ).value,

            telephone:
            document
            .getElementById(
            "editTelephone"
            ).value,

            gmail:
            document
            .getElementById(
            "editGmail"
            ).value

        })

    })
    .then(()=>{

        closeModal();
        loadClients();

    });

}

loadClients();