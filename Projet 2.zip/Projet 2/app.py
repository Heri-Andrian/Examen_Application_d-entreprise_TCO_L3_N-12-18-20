from flask import Flask
from flask import render_template

from database.db import init_db
from controllers.client_controller import client_bp

app = Flask(__name__)

init_db()

app.register_blueprint(client_bp)


@app.route("/")
def index():
    return render_template("index.html")


if __name__ == "__main__":
    app.run(
        debug=True
    )