"""
ClientService - Couche service (SERVICE / LOGIQUE MÉTIER)
Contient les règles métier et la validation des données.
Fait le lien entre le Controller et le Repository.
"""

from repository.client_repository import ClientRepository
from models.client import Client


class ClientService:
    """Contient la logique métier pour la gestion des clients"""

    def __init__(self):
        self.repository = ClientRepository()

    def ajouter_client(self, nom, gmail, telephone=""):
        """Valide les données et ajoute un nouveau client"""

        # ── Validation des champs obligatoires ──────────────────────────────
        if not nom or not nom.strip():
            raise ValueError("Le nom du client est obligatoire.")
        if not gmail or not gmail.strip():
            raise ValueError("Le Gmail du client est obligatoire.")
        if not telephone or not telephone.strip():
            raise ValueError("Le numéro de téléphone est obligatoire.")

        # ── ✅ NOUVEAU : vérification d'unicité ─────────────────────────────
        if self.repository.gmail_existe(gmail.strip()):
            raise ValueError("Cette adresse Gmail est déjà utilisée par un autre client.")

        if self.repository.telephone_existe(telephone.strip()):
            raise ValueError("Ce numéro de téléphone est déjà utilisé par un autre client.")

        # ── Création et enregistrement ───────────────────────────────────────
        client = Client(
            id=None,
            nom=nom.strip(),
            gmail=gmail.strip(),
            telephone=telephone.strip(),
        )
        return self.repository.ajouter(client)

    def lister_clients(self):
        """Retourne la liste de tous les clients"""
        return self.repository.obtenir_tous()

    def modifier_client(self, client_id, nom, gmail, telephone=""):
        """Valide et modifie les informations d'un client existant"""

        # ── Validation des champs obligatoires ──────────────────────────────
        if not nom or not nom.strip():
            raise ValueError("Le nom du client est obligatoire.")
        if not gmail or not gmail.strip():
            raise ValueError("Le Gmail du client est obligatoire.")
        if not telephone or not telephone.strip():
            raise ValueError("Le numéro de téléphone est obligatoire.")

        # ── Vérifier que le client existe ────────────────────────────────────
        client = self.repository.obtenir_par_id(client_id)
        if not client:
            return None

        # ── ✅ NOUVEAU : vérification d'unicité (en excluant le client lui-même)
        # exclude_id=client_id permet au client de conserver son propre gmail/téléphone
        if self.repository.gmail_existe(gmail.strip(), exclude_id=client_id):
            raise ValueError("Cette adresse Gmail est déjà utilisée par un autre client.")

        if self.repository.telephone_existe(telephone.strip(), exclude_id=client_id):
            raise ValueError("Ce numéro de téléphone est déjà utilisé par un autre client.")

        # ── Mise à jour des champs (sauf l'ID) ──────────────────────────────
        client.nom       = nom.strip()
        client.gmail     = gmail.strip()
        client.telephone = telephone.strip()

        self.repository.modifier(client)
        return client

    def supprimer_client(self, client_id):
        """Supprime un client par son ID"""
        self.repository.supprimer(client_id)